/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[57];
    char stringdata0[1303];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 19), // "on_ClearBtn_clicked"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 19), // "on_Loginbtn_clicked"
QT_MOC_LITERAL(4, 52, 13), // "keyPressEvent"
QT_MOC_LITERAL(5, 66, 10), // "QKeyEvent*"
QT_MOC_LITERAL(6, 77, 2), // "pe"
QT_MOC_LITERAL(7, 80, 25), // "on_gotodisplaybtn_clicked"
QT_MOC_LITERAL(8, 106, 34), // "on_teamcombobox_currentTextCh..."
QT_MOC_LITERAL(9, 141, 4), // "arg1"
QT_MOC_LITERAL(10, 146, 32), // "on_displaystadiumteambtn_clicked"
QT_MOC_LITERAL(11, 179, 31), // "on_disstadiumstadiumbtn_clicked"
QT_MOC_LITERAL(12, 211, 26), // "on_disAmericanTeam_clicked"
QT_MOC_LITERAL(13, 238, 25), // "on_disNationalbtn_clicked"
QT_MOC_LITERAL(14, 264, 28), // "on_disstadiumtypobtn_clicked"
QT_MOC_LITERAL(15, 293, 26), // "on_disteamopenroof_clicked"
QT_MOC_LITERAL(16, 320, 25), // "on_disstaddatebtn_clicked"
QT_MOC_LITERAL(17, 346, 26), // "on_disstadiumseats_clicked"
QT_MOC_LITERAL(18, 373, 30), // "on_disstadiumlarcenter_clicked"
QT_MOC_LITERAL(19, 404, 31), // "on_disstadiumsmalcenter_clicked"
QT_MOC_LITERAL(20, 436, 23), // "on_loadTeamInfo_clicked"
QT_MOC_LITERAL(21, 460, 27), // "on_loadSouvenirInfo_clicked"
QT_MOC_LITERAL(22, 488, 22), // "on_Backtoadmin_clicked"
QT_MOC_LITERAL(23, 511, 22), // "on_loadDatabtn_clicked"
QT_MOC_LITERAL(24, 534, 26), // "on_loadstadiumsbtn_clicked"
QT_MOC_LITERAL(25, 561, 21), // "on_backtopass_clicked"
QT_MOC_LITERAL(26, 583, 18), // "on_AddSouv_clicked"
QT_MOC_LITERAL(27, 602, 22), // "on_Souvenirbtn_clicked"
QT_MOC_LITERAL(28, 625, 22), // "on_BacktoAdmin_clicked"
QT_MOC_LITERAL(29, 648, 26), // "on_TeamCombosouv_activated"
QT_MOC_LITERAL(30, 675, 24), // "on_deleteSouvbtn_clicked"
QT_MOC_LITERAL(31, 700, 29), // "on_Souveniralltable_activated"
QT_MOC_LITERAL(32, 730, 11), // "QModelIndex"
QT_MOC_LITERAL(33, 742, 5), // "index"
QT_MOC_LITERAL(34, 748, 22), // "on_Editsouvbtn_clicked"
QT_MOC_LITERAL(35, 771, 21), // "on_EditMlBbtn_clicked"
QT_MOC_LITERAL(36, 793, 28), // "on_stadiumcombobox_activated"
QT_MOC_LITERAL(37, 822, 24), // "on_Backtoadmin_2_clicked"
QT_MOC_LITERAL(38, 847, 22), // "on_editstadium_clicked"
QT_MOC_LITERAL(39, 870, 17), // "on_DFSbtn_clicked"
QT_MOC_LITERAL(40, 888, 17), // "on_BFSbtn_clicked"
QT_MOC_LITERAL(41, 906, 17), // "on_MSTbtn_clicked"
QT_MOC_LITERAL(42, 924, 22), // "on_backtologin_clicked"
QT_MOC_LITERAL(43, 947, 25), // "on_dodgers_button_clicked"
QT_MOC_LITERAL(44, 973, 30), // "on_startStadium_button_clicked"
QT_MOC_LITERAL(45, 1004, 25), // "on_marlins_button_clicked"
QT_MOC_LITERAL(46, 1030, 24), // "on_custom_button_clicked"
QT_MOC_LITERAL(47, 1055, 28), // "on_traversals_button_clicked"
QT_MOC_LITERAL(48, 1084, 21), // "on_add_button_clicked"
QT_MOC_LITERAL(49, 1106, 24), // "on_delete_button_clicked"
QT_MOC_LITERAL(50, 1131, 26), // "on_tripSelect_back_clicked"
QT_MOC_LITERAL(51, 1158, 27), // "on_calculatesouvbtn_clicked"
QT_MOC_LITERAL(52, 1186, 23), // "on_clearsouvbtn_clicked"
QT_MOC_LITERAL(53, 1210, 21), // "on_backtotrip_clicked"
QT_MOC_LITERAL(54, 1232, 22), // "on_select_done_clicked"
QT_MOC_LITERAL(55, 1255, 24), // "on_backtologin_2_clicked"
QT_MOC_LITERAL(56, 1280, 22) // "on_backtoadmin_clicked"

    },
    "MainWindow\0on_ClearBtn_clicked\0\0"
    "on_Loginbtn_clicked\0keyPressEvent\0"
    "QKeyEvent*\0pe\0on_gotodisplaybtn_clicked\0"
    "on_teamcombobox_currentTextChanged\0"
    "arg1\0on_displaystadiumteambtn_clicked\0"
    "on_disstadiumstadiumbtn_clicked\0"
    "on_disAmericanTeam_clicked\0"
    "on_disNationalbtn_clicked\0"
    "on_disstadiumtypobtn_clicked\0"
    "on_disteamopenroof_clicked\0"
    "on_disstaddatebtn_clicked\0"
    "on_disstadiumseats_clicked\0"
    "on_disstadiumlarcenter_clicked\0"
    "on_disstadiumsmalcenter_clicked\0"
    "on_loadTeamInfo_clicked\0"
    "on_loadSouvenirInfo_clicked\0"
    "on_Backtoadmin_clicked\0on_loadDatabtn_clicked\0"
    "on_loadstadiumsbtn_clicked\0"
    "on_backtopass_clicked\0on_AddSouv_clicked\0"
    "on_Souvenirbtn_clicked\0on_BacktoAdmin_clicked\0"
    "on_TeamCombosouv_activated\0"
    "on_deleteSouvbtn_clicked\0"
    "on_Souveniralltable_activated\0QModelIndex\0"
    "index\0on_Editsouvbtn_clicked\0"
    "on_EditMlBbtn_clicked\0"
    "on_stadiumcombobox_activated\0"
    "on_Backtoadmin_2_clicked\0"
    "on_editstadium_clicked\0on_DFSbtn_clicked\0"
    "on_BFSbtn_clicked\0on_MSTbtn_clicked\0"
    "on_backtologin_clicked\0on_dodgers_button_clicked\0"
    "on_startStadium_button_clicked\0"
    "on_marlins_button_clicked\0"
    "on_custom_button_clicked\0"
    "on_traversals_button_clicked\0"
    "on_add_button_clicked\0on_delete_button_clicked\0"
    "on_tripSelect_back_clicked\0"
    "on_calculatesouvbtn_clicked\0"
    "on_clearsouvbtn_clicked\0on_backtotrip_clicked\0"
    "on_select_done_clicked\0on_backtologin_2_clicked\0"
    "on_backtoadmin_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      50,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  264,    2, 0x08 /* Private */,
       3,    0,  265,    2, 0x08 /* Private */,
       4,    1,  266,    2, 0x08 /* Private */,
       7,    0,  269,    2, 0x08 /* Private */,
       8,    1,  270,    2, 0x08 /* Private */,
      10,    0,  273,    2, 0x08 /* Private */,
      11,    0,  274,    2, 0x08 /* Private */,
      12,    0,  275,    2, 0x08 /* Private */,
      13,    0,  276,    2, 0x08 /* Private */,
      14,    0,  277,    2, 0x08 /* Private */,
      15,    0,  278,    2, 0x08 /* Private */,
      16,    0,  279,    2, 0x08 /* Private */,
      17,    0,  280,    2, 0x08 /* Private */,
      18,    0,  281,    2, 0x08 /* Private */,
      19,    0,  282,    2, 0x08 /* Private */,
      20,    0,  283,    2, 0x08 /* Private */,
      21,    0,  284,    2, 0x08 /* Private */,
      22,    0,  285,    2, 0x08 /* Private */,
      23,    0,  286,    2, 0x08 /* Private */,
      24,    0,  287,    2, 0x08 /* Private */,
      25,    0,  288,    2, 0x08 /* Private */,
      26,    0,  289,    2, 0x08 /* Private */,
      27,    0,  290,    2, 0x08 /* Private */,
      28,    0,  291,    2, 0x08 /* Private */,
      29,    1,  292,    2, 0x08 /* Private */,
      30,    0,  295,    2, 0x08 /* Private */,
      31,    1,  296,    2, 0x08 /* Private */,
      34,    0,  299,    2, 0x08 /* Private */,
      35,    0,  300,    2, 0x08 /* Private */,
      36,    1,  301,    2, 0x08 /* Private */,
      37,    0,  304,    2, 0x08 /* Private */,
      38,    0,  305,    2, 0x08 /* Private */,
      39,    0,  306,    2, 0x08 /* Private */,
      40,    0,  307,    2, 0x08 /* Private */,
      41,    0,  308,    2, 0x08 /* Private */,
      42,    0,  309,    2, 0x08 /* Private */,
      43,    0,  310,    2, 0x08 /* Private */,
      44,    0,  311,    2, 0x08 /* Private */,
      45,    0,  312,    2, 0x08 /* Private */,
      46,    0,  313,    2, 0x08 /* Private */,
      47,    0,  314,    2, 0x08 /* Private */,
      48,    0,  315,    2, 0x08 /* Private */,
      49,    0,  316,    2, 0x08 /* Private */,
      50,    0,  317,    2, 0x08 /* Private */,
      51,    0,  318,    2, 0x08 /* Private */,
      52,    0,  319,    2, 0x08 /* Private */,
      53,    0,  320,    2, 0x08 /* Private */,
      54,    0,  321,    2, 0x08 /* Private */,
      55,    0,  322,    2, 0x08 /* Private */,
      56,    0,  323,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 5,    6,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 32,   33,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_ClearBtn_clicked(); break;
        case 1: _t->on_Loginbtn_clicked(); break;
        case 2: _t->keyPressEvent((*reinterpret_cast< QKeyEvent*(*)>(_a[1]))); break;
        case 3: _t->on_gotodisplaybtn_clicked(); break;
        case 4: _t->on_teamcombobox_currentTextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 5: _t->on_displaystadiumteambtn_clicked(); break;
        case 6: _t->on_disstadiumstadiumbtn_clicked(); break;
        case 7: _t->on_disAmericanTeam_clicked(); break;
        case 8: _t->on_disNationalbtn_clicked(); break;
        case 9: _t->on_disstadiumtypobtn_clicked(); break;
        case 10: _t->on_disteamopenroof_clicked(); break;
        case 11: _t->on_disstaddatebtn_clicked(); break;
        case 12: _t->on_disstadiumseats_clicked(); break;
        case 13: _t->on_disstadiumlarcenter_clicked(); break;
        case 14: _t->on_disstadiumsmalcenter_clicked(); break;
        case 15: _t->on_loadTeamInfo_clicked(); break;
        case 16: _t->on_loadSouvenirInfo_clicked(); break;
        case 17: _t->on_Backtoadmin_clicked(); break;
        case 18: _t->on_loadDatabtn_clicked(); break;
        case 19: _t->on_loadstadiumsbtn_clicked(); break;
        case 20: _t->on_backtopass_clicked(); break;
        case 21: _t->on_AddSouv_clicked(); break;
        case 22: _t->on_Souvenirbtn_clicked(); break;
        case 23: _t->on_BacktoAdmin_clicked(); break;
        case 24: _t->on_TeamCombosouv_activated((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 25: _t->on_deleteSouvbtn_clicked(); break;
        case 26: _t->on_Souveniralltable_activated((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 27: _t->on_Editsouvbtn_clicked(); break;
        case 28: _t->on_EditMlBbtn_clicked(); break;
        case 29: _t->on_stadiumcombobox_activated((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 30: _t->on_Backtoadmin_2_clicked(); break;
        case 31: _t->on_editstadium_clicked(); break;
        case 32: _t->on_DFSbtn_clicked(); break;
        case 33: _t->on_BFSbtn_clicked(); break;
        case 34: _t->on_MSTbtn_clicked(); break;
        case 35: _t->on_backtologin_clicked(); break;
        case 36: _t->on_dodgers_button_clicked(); break;
        case 37: _t->on_startStadium_button_clicked(); break;
        case 38: _t->on_marlins_button_clicked(); break;
        case 39: _t->on_custom_button_clicked(); break;
        case 40: _t->on_traversals_button_clicked(); break;
        case 41: _t->on_add_button_clicked(); break;
        case 42: _t->on_delete_button_clicked(); break;
        case 43: _t->on_tripSelect_back_clicked(); break;
        case 44: _t->on_calculatesouvbtn_clicked(); break;
        case 45: _t->on_clearsouvbtn_clicked(); break;
        case 46: _t->on_backtotrip_clicked(); break;
        case 47: _t->on_select_done_clicked(); break;
        case 48: _t->on_backtologin_2_clicked(); break;
        case 49: _t->on_backtoadmin_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 50)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 50;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 50)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 50;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
